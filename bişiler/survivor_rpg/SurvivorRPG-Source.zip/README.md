# 🎮 Survivor RPG - Professional Edition

Profesyonel survivor tarzı aksiyon RPG oyunu. Mobil cihazlar için optimize edilmiş.

## ✨ Özellikler

- 🎯 **Akıllı Kontroller**: Mouse/Touch ile sezgisel hareket
- 📱 **Mobil Uyumlu**: Tek el ile oynanabilir
- ⚡ **Gelişmiş Grafikler**: Parçacık efektleri ve animasyonlar
- 🆙 **Level Sistemi**: Yetenekler ve güçlendirmeler
- 🎨 **Modern UI**: Temiz ve kullanıcı dostu arayüz

## 🎮 Kontroller

### Masaüstü
- **Mouse**: Karakterin gitmesini istediğin yöne tıkla

### Mobil
- **Sol yarı ekran**: Joystick kontrolü
- **Sağ yarı ekran**: Touch ile hareket

## 🔧 Kurulum

### Python ile Çalıştırma
```bash
pip install -r requirements.txt
python main.py
```

### APK Oluşturma
```bash
# Buildozer ile
buildozer android debug

# Veya GitHub Actions kullan (otomatik)
```

## 📱 APK İndirme

1. Bu repo'yu GitHub'a yükle
2. GitHub Actions otomatik olarak APK oluşturacak
3. Actions sekmesinden APK'yı indir

## 🎯 Oynanış

- Düşmanlardan kaçın ve onları yok edin
- XP toplayarak level atlayın
- Yetenekler seçerek güçlenin
- Mümkün olduğunca uzun süre hayatta kalın!

## 🛠️ Geliştirme

- **Framework**: Kivy
- **Platform**: Cross-platform (Windows, Linux, Android)
- **Dil**: Python 3.8+

## 📄 Lisans

MIT License - Özgürce kullanabilirsiniz!