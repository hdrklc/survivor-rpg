# Entity modülleri
