# 📱 APK Oluşturma Rehberi

## 🌐 Online Buildozer (Önerilen)

### 1. Replit.com Kullanma
1. [Replit.com](https://replit.com) hesabı oluştur
2. "Create Repl" → "Import from GitHub" (veya dosyaları yükle)
3. Terminal'de şu komutları çalıştır:
```bash
pip install buildozer
buildozer init
buildozer android debug
```

### 2. Google Colab Kullanma
1. [Google Colab](https://colab.research.google.com) aç
2. Yeni notebook oluştur
3. Şu kodu çalıştır:

```python
# Dosyaları yükle
from google.colab import files
import os

# Buildozer kur
!pip install buildozer

# APK oluştur
!buildozer android debug

# APK'yı indir
files.download('bin/survivorrpg-1.0-debug.apk')
```

## 🖥️ Windows'ta Lokal Build

### WSL Kurulumu (Önerilen)
```powershell
# PowerShell'i admin olarak aç
wsl --install -d Ubuntu

# Ubuntu'yu başlat ve şu komutları çalıştır:
sudo apt update
sudo apt install -y python3-pip git
pip3 install buildozer

# Proje klasörüne git
cd /mnt/c/Users/hidir/Desktop/bişiler/survivor_rpg
buildozer android debug
```

### Docker ile Build
```bash
# Docker kurulu ise
docker run --rm -v ${PWD}:/workspace kivy/buildozer android debug
```

## 📦 Hazır APK İndirme Linkleri

Eğer build etmek istemiyorsan, şu servislerden hazır APK indirebilirsin:

1. **GitHub Actions** (otomatik build)
2. **F-Droid** (açık kaynak apps)
3. **APKPure** (APK dağıtım)

## 🎯 Hızlı Test

APK oluşturmadan önce masaüstünde test et:
```bash
python main.py
```

Sorunsuz çalışıyorsa APK build'i de çalışacaktır!
