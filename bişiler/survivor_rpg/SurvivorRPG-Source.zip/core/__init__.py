# Core sistem modülleri
