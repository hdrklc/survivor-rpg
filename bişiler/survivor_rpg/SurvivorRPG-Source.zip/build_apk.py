#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
APK Build Helper Script
Bu script APK oluşturma sürecini kolaylaştırır
"""

import os
import sys
import subprocess
import shutil

def check_dependencies():
    """Gerekli bağımlılıkları kontrol et"""
    print("🔍 Bağımlılıklar kontrol ediliyor...")
    
    # Python kontrolü
    if sys.version_info < (3, 8):
        print("❌ Python 3.8+ gerekli!")
        return False
    
    # Buildozer kontrolü
    try:
        subprocess.run(["buildozer", "--version"], capture_output=True, check=True)
        print("✅ Buildozer mevcut")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("❌ Buildozer kurulu değil!")
        print("📥 Kurulum: pip install buildozer")
        return False
    
    return True

def build_apk():
    """APK oluştur"""
    print("\n🏗️ APK oluşturuluyor...")
    
    try:
        # Buildozer init (eğer spec dosyası yoksa)
        if not os.path.exists("buildozer.spec"):
            print("📝 buildozer.spec oluşturuluyor...")
            subprocess.run(["buildozer", "init"], check=True)
        
        # APK build
        print("🔨 APK build başlıyor... (Bu işlem uzun sürebilir)")
        result = subprocess.run(["buildozer", "android", "debug"], 
                              capture_output=False, text=True)
        
        if result.returncode == 0:
            print("✅ APK başarıyla oluşturuldu!")
            
            # APK dosyasını bul
            bin_dir = "bin"
            if os.path.exists(bin_dir):
                apk_files = [f for f in os.listdir(bin_dir) if f.endswith('.apk')]
                if apk_files:
                    apk_path = os.path.join(bin_dir, apk_files[0])
                    print(f"📱 APK konumu: {apk_path}")
                    print(f"📏 Dosya boyutu: {os.path.getsize(apk_path) / (1024*1024):.1f} MB")
                    
                    # APK'yı masaüstüne kopyala
                    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
                    if os.path.exists(desktop):
                        desktop_apk = os.path.join(desktop, "SurvivorRPG.apk")
                        shutil.copy2(apk_path, desktop_apk)
                        print(f"📋 APK masaüstüne kopyalandı: {desktop_apk}")
            
            return True
        else:
            print("❌ APK oluşturma başarısız!")
            return False
            
    except subprocess.CalledProcessError as e:
        print(f"❌ Hata: {e}")
        return False

def install_buildozer():
    """Buildozer kurulumunu dene"""
    print("📥 Buildozer kuruluyor...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "buildozer"], check=True)
        print("✅ Buildozer kuruldu!")
        return True
    except subprocess.CalledProcessError:
        print("❌ Buildozer kurulumu başarısız!")
        return False

def main():
    """Ana fonksiyon"""
    print("🎮 Survivor RPG - APK Builder")
    print("=" * 40)
    
    # Bağımlılık kontrolü
    if not check_dependencies():
        choice = input("\n🤔 Buildozer'ı kurmaya çalışalım mı? (y/n): ")
        if choice.lower() == 'y':
            if not install_buildozer():
                return
        else:
            print("\n📖 Manuel kurulum:")
            print("   pip install buildozer")
            return
    
    # APK oluştur
    print(f"\n📂 Çalışma dizini: {os.getcwd()}")
    
    choice = input("\n🚀 APK oluşturmaya başlayalım mı? (y/n): ")
    if choice.lower() == 'y':
        if build_apk():
            print("\n🎉 Başarılı! APK telefona yüklenebilir.")
            print("📱 Android'de 'Bilinmeyen kaynaklar'ı etkinleştir")
        else:
            print("\n💡 Alternatif yöntemler:")
            print("   1. Online Buildozer (Replit/Colab)")
            print("   2. WSL ile Linux ortamı")
            print("   3. GitHub Actions")
    else:
        print("👋 İptal edildi!")

if __name__ == "__main__":
    main()
