# Google Colab'da çalıştır: https://colab.research.google.com

# 1. Dosyaları yükle
from google.colab import files
import zipfile
import os

print("📁 Oyun dosyalarını zip olarak yükle...")
uploaded = files.upload()

# Zip'i çıkart
for filename in uploaded.keys():
    if filename.endswith('.zip'):
        with zipfile.ZipFile(filename, 'r') as zip_ref:
            zip_ref.extractall('survivor_rpg')
        break

# 2. Buildozer kur
print("📦 Buildozer kuruluyor...")
!pip install buildozer

# 3. APK oluştur
print("🔨 APK oluşturuluyor...")
os.chdir('survivor_rpg')
!buildozer android debug

# 4. APK'yı indir
print("📱 APK indiriliyor...")
apk_files = [f for f in os.listdir('bin/') if f.endswith('.apk')]
if apk_files:
    files.download(f'bin/{apk_files[0]}')
    print("✅ APK başarıyla indirildi!")
else:
    print("❌ APK bulunamadı!")
